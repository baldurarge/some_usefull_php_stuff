<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
	<title></title>
</head>
<body>
<form name="formCompanys" method="post" action="theClass.php">
	<div class="row">
		<input type="text" name="kennitala" placeholder="Kennitala"><br>
		<input type="text" name="fName" placeholder="First Name"><br>
		<input type="text" name="lName" placeholder="Last Name"><br>
		<input type="text" name="email" placeholder="Email"><br>
		<input type="text" name="simi" placeholder="S�mi"><br>
		<input type="text" name="heimili" placeholder="Heimilisfang"><br>
	</div>
	<input type="submit">
</form>
</body></html>
